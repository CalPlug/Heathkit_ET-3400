using System.Collections.Generic;

namespace Core6800
{
    public partial class Cpu6800
    {
        // Registers
        public Cpu6800State State;

        // housekeeping
        public List<int> Breakpoint = new List<int>();

    }
}

namespace Sharp6800.Common
{
    public enum EmulationModes
    {
        Regular,
        CycleExact
    }
}
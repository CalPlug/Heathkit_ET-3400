using Core6800;

namespace Sharp6800.Common
{
    public delegate void OnUpdateDelegate(Cpu6800 emu);
}
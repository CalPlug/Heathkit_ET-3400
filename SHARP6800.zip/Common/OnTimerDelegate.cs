namespace Sharp6800.Common
{
    public delegate void OnTimerDelegate(int cyclePerSecond);
}
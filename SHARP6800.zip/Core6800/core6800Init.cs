using System.Diagnostics;

namespace Core6800
{
    public partial class Cpu6800
    {
        public void Initialize()
        {
            //NMI = 1;
            //IRQ = 1;

        }
    }
}
